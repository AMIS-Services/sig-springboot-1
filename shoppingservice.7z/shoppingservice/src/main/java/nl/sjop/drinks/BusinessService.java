package nl.sjop.drinks;

public interface BusinessService {
}
