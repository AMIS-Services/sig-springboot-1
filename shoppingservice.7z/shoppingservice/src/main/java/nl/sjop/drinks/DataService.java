package nl.sjop.drinks;

import java.util.List;

public interface DataService {
    List<String> retrieveData();
}
